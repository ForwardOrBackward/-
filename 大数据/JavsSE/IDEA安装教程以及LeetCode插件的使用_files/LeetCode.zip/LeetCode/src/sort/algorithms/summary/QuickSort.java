package sort.algorithms.summary;

import java.util.Arrays;

public class QuickSort {
    public static void main(String[] args) {
        int[] array = new int[]{2, 1, 3, 5, 4, 3, 9, 2, 4, 1, 2, 8, 0};
        sort.algorithms.summary.QuickSort qs = new sort.algorithms.summary.QuickSort();
        qs.quickSort(array, 0, array.length - 1);
        System.out.println(Arrays.toString(array));
    }

    /**
     * 下面这种写法是先后找到索引i和j要移动的值, 然后索引i和j的值互换, 然后array[low]的值最后才换, 换成array[i]的值(此时i等于j)
     */
    void quickSort(int[] array, int low, int high) {
        if (low < high) {
            int i = low, j = high;
            int tmp = array[low];
            while (i < j) {
                while (i < j && array[j] >= array[low]) j--; //注意while循环里的比较值只能是array[low]比较而不是tmp。
                while (i < j && array[i] <= array[low]) i++; //注意while循环里的比较值只能是array[low]比较而不是tmp。
                //索引i和j的值互换。在两个while之后导致了i==j时,i和j对应的值还会交换一次,并且记录tmp的值为array[i]。
                //这里有个缺点就是i和j互换完后,如果i<j, 还要再循环一次使得i和j走一步(即使i和j只相差一格),
                // 这里还不能在交换后末尾直接加上i++和j--, 否则递归会出错。
                tmp = array[i];
                array[i] = array[j];
                array[j] = tmp;
            }
            //i==j时,索引i和tmp的值互换。
            array[i] = array[low];
            array[low] = tmp;

            quickSort(array, low, i - 1);
            quickSort(array, i + 1, high);
        }
    }

    /**
     * 下面这种写法是在第一次找到j要移动的值时, 直接覆盖array[low]的值, 然后找到i要移动的值时又直接覆盖j的值, 然后i==j时直接将存在
     * tmp里的array[low]的值直接赋给array[i]。这种写法更好理解。
     */
    void quickSort2(int[] array, int low, int high) {
        if (low < high) {
            int i = low, j = high;
            int tmp = array[low];
            while (i < j) {
                //下面的两个while循环中必须至少要有一个"="号, 可以两个都有"=", 不能两个都没有"="。
                while (i < j && array[j] >= tmp) j--;  //注意while循环里的比较值只能是tmp比较而不是array[low]。
                if (i < j) { //先将索引j的值交给i。第一次交换直接将array[low]的值覆盖。
                    array[i] = array[j];
                    i++;
                }
                while (i < j && array[i] <= tmp) i++; //注意while循环里的比较值只能是tmp比较而不是array[low]。
                if (i < j) {
                    array[j] = array[i];
                    j--;
                }
            }
            array[i] = tmp; //这里只需把tmp值赋给array[i]。
            quickSort2(array, low, i - 1);
            quickSort2(array, i + 1, high);
        }
    }

}



