package sort.algorithms.summary;

import java.util.Arrays;

/**
 * 这是原始的二路归并算法, 后面有改进版
 */
//public class MergeSort {
//
//    public static void main(String[] args) {
//        int[] arr = {6, 9, 1, 4, 5, 8, 7, 0, 2, 3};
//        mergeSort(arr, 0, arr.length - 1);
//        System.out.println(Arrays.toString(arr));
//    }
//
//    private static void mergeSort(int[] arr, int low, int high) {
//        if (low < high) {
//            // 计算出中间值，这种算法保证不会溢出。
//            int mid = low + ((high - low) >> 1);  //int mid = (low + high) / 2;
//            // 先对左边排序
//            mergeSort(arr, low, mid);
//            // 先对右边排序
//            mergeSort(arr, mid + 1, high);
//            // 归并两个有序的子序列
//            merge(arr, low, mid, high);
//        }
//    }
//    private static void merge(int[] arr, int low, int mid, int high) {
//        // temp[]是临时数组, 用来合并左右两边排好序的arr数组部分。
//        int[] temp = new int[high - low + 1];
//        int left = low; // 左侧指针从low开始。
//        int right = mid + 1;    // 右侧指针从mid+1开始。
//        int index = 0;  // 此索引用于记录temp[]归并到了哪里。
//        // 当两个子序列还有元素时，从小到大放入temp[]中。
//        while (left <= mid && right <= high) {
//            if (arr[left] < arr[right]) {
//                temp[index++] = arr[left++];
//            } else {
//                temp[index++] = arr[right++];
//            }
//        }
//        // 如果arr左边部分还有元素没有放入temp[]中
//        while (left <= mid) {
//            temp[index++] = arr[left++];
//        }
//        // 如果arr右边部分还有元素没有放入temp[]中
//        while (right <= high) {
//            temp[index++] = arr[right++];
//        }
//
//        // 将tmp里的结果重新赋值给arr对应的区间, 注意,只是arr的部分区间。
//        for (int i = 0; i < temp.length; i++) { //i的取值范围改为[0, temp.length)
//            arr[low + i] = temp[i];
//        }
//    }
//}

/**
 * 这里是对上面的原始MergeSort算法的改进, 因为上面的归并算法每次调用merge()方法都会new一个temp, 其实全局使用一个temp就够了。
 * 下面的写法除了将temp当成方法参数传递外, 还可以用全局变量来省略temp的多次传递。
 */
public class MergeSort {

    public static void main(String[] args) {
        int[] arr = {6, 9, 1, 4, 5, 8, 7, 0, 2, 3};
        int[] temp = new int[arr.length];//temp数组的内存分配放在这里。
        mergeSort(arr, 0, arr.length - 1, temp);
        System.out.println(Arrays.toString(arr));
    }


    private static void mergeSort(int[] arr, int low, int high, int[] temp) { //增减一个temp参数
        if (low < high) {
            int mid = low + ((high - low) >> 1);  //int mid = (low + high) / 2;
            mergeSort(arr, low, mid, temp);
            mergeSort(arr, mid + 1, high, temp);
            merge(arr, low, mid, high, temp);
        }
    }

    private static void merge(int[] arr, int low, int mid, int high, int[] temp) { //增减一个temp参数
        int left = low;
        int right = mid + 1;
        //index不用变, 还是指在temp数组的0处,毕竟temp数组只是用过临时存的, 不需要和arr数组位置一一对应。
        // 如果要一一对应也可以 那么这里这里应该是int index = low; 后面的for循环则对应变成如下(会更加简便):
        //      for (int i = low; i < high; i++) arr[i] = temp[i];
        int index = 0;
        while (left <= mid && right <= high) {
            if (arr[left] < arr[right]) {
                temp[index++] = arr[left++];
            } else {
                temp[index++] = arr[right++];
            }
        }
        while (left <= mid) {
            temp[index++] = arr[left++];
        }
        while (right <= high) {
            temp[index++] = arr[right++];
        }

        // 将tmp里的结果重新赋值给arr对应的区间。
        for (int i = 0; i < index; i++) { //i的取值范围改为[0, index)
            arr[low + i] = temp[i];
        }
    }
}