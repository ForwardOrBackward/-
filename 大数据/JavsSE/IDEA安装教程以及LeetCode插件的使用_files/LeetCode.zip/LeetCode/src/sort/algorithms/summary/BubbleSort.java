package sort.algorithms.summary;

public class BubbleSort {
    public void sort(int[] nums) {
        for (int i = nums.length - 1; i >= 0; i--) {
            boolean flag = false;
            for (int j = 1; j <= i; j++) {
                if (nums[j - 1] > nums[j]) {
                    int tmp = nums[j];
                    nums[j] = nums[j - 1];
                    nums[j - 1] = tmp;
                    flag = true;
                }
            }
            if (!flag) return;
        }
    }
}