package leetcode.editor.cn;
//给定一个二叉树，返回其节点值的锯齿形层序遍历。（即先从左往右，再从右往左进行下一层遍历，以此类推，层与层之间交替进行）。 
//
// 例如： 
//给定二叉树 [3,9,20,null,null,15,7], 
//
// 
//    3
//   / \
//  9  20
//    /  \
//   15   7
// 
//
// 返回锯齿形层序遍历如下： 
//
// 
//[
//  [3],
//  [20,9],
//  [15,7]
//]
// 
// Related Topics 树 广度优先搜索 二叉树 
// 👍 495 👎 0


import java.util.LinkedList;
import java.util.List;

//java:二叉树的锯齿形层序遍历
public class P103_BinaryTreeZigzagLevelOrderTraversal{
    public static void main(String[] args) {
        Solution solution = new P103_BinaryTreeZigzagLevelOrderTraversal().new Solution();
        //测试代码:
        
    }    
//leetcode submit region begin(Prohibit modification and deletion)
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode() {}
 *     TreeNode(int val) { this.val = val; }
 *     TreeNode(int val, TreeNode left, TreeNode right) {
 *         this.val = val;
 *         this.left = left;
 *         this.right = right;
 *     }
 * }
 */
class Solution {
    public List<List<Integer>> zigzagLevelOrder(TreeNode root) {
            if(root == null) return new LinkedList<>();
            List<List<Integer>> result = new LinkedList<>();
            LinkedList<TreeNode> list = new LinkedList<>();
            list.addLast(root);
            boolean tag = false;
            while (!list.isEmpty()){
                List<Integer> row = new LinkedList<>();
                for(int i = list.size(); i > 0; i--){
                    TreeNode node;
                    if(!tag){
                        node = list.removeFirst();
                        if(node.left != null) list.addLast(node.left);
                        if(node.right != null) list.addLast(node.right);
                    }else {
                        node = list.removeLast();
                        if(node.right != null) list.addFirst(node.right);
                        if(node.left != null) list.addFirst(node.left);
                    }
                    row.add(node.val);
                }
                tag = !tag;
                result.add(row);


            }
            return result;
    }
}
//leetcode submit region end(Prohibit modification and deletion)

}