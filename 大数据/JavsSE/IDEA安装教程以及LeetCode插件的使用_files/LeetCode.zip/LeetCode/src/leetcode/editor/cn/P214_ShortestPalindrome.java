package leetcode.editor.cn;
//给定一个字符串 s，你可以通过在字符串前面添加字符将其转换为回文串。找到并返回可以用这种方式转换的最短回文串。 
//
// 
//
// 示例 1： 
//
// 
//输入：s = "aacecaaa"
//输出："aaacecaaa"
// 
//
// 示例 2： 
//
// 
//输入：s = "abcd"
//输出："dcbabcd"
// 
//
// 
//
// 提示： 
//
// 
// 0 <= s.length <= 5 * 104 
// s 仅由小写英文字母组成 
// 
// Related Topics 字符串 
// 👍 329 👎 0


//java:最短回文串
public class P214_ShortestPalindrome{
    public static void main(String[] args) {
        Solution solution = new P214_ShortestPalindrome().new Solution();
        //测试代码:
        
    }    
//leetcode submit region begin(Prohibit modification and deletion)
class Solution {
    public String shortestPalindrome(String s) {

    }
}
//leetcode submit region end(Prohibit modification and deletion)

}
