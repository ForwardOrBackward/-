package leetcode.editor.cn;
//给定一个只包含数字的字符串，用以表示一个 IP 地址，返回所有可能从 s 获得的 有效 IP 地址 。你可以按任何顺序返回答案。 
//
// 有效 IP 地址 正好由四个整数（每个整数位于 0 到 255 之间组成，且不能含有前导 0），整数之间用 '.' 分隔。 
//
// 例如："0.1.2.201" 和 "192.168.1.1" 是 有效 IP 地址，但是 "0.011.255.245"、"192.168.1.312" 
//和 "192.168@1.1" 是 无效 IP 地址。 
//
// 
//
// 示例 1： 
//
// 
//输入：s = "25525511135"
//输出：["255.255.11.135","255.255.111.35"]
// 
//
// 示例 2： 
//
// 
//输入：s = "0000"
//输出：["0.0.0.0"]
// 
//
// 示例 3： 
//
// 
//输入：s = "1111"
//输出：["1.1.1.1"]
// 
//
// 示例 4： 
//
// 
//输入：s = "010010"
//输出：["0.10.0.10","0.100.1.0"]
// 
//
// 示例 5： 
//
// 
//输入：s = "101023"
//输出：["1.0.10.23","1.0.102.3","10.1.0.23","10.10.2.3","101.0.2.3"]
// 
//
// 
//
// 提示： 
//
// 
// 0 <= s.length <= 3000 
// s 仅由数字组成 
// 
// Related Topics 字符串 回溯算法 
// 👍 560 👎 0


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

//java:复原 IP 地址
public class P93_RestoreIpAddresses{
    public static void main(String[] args) {
        Solution solution = new P93_RestoreIpAddresses().new Solution();
        //测试代码:
        System.out.println(solution.restoreIpAddresses("0112"));
    }    
//leetcode submit region begin(Prohibit modification and deletion)
//class Solution {//解法一: 塞点法。将三个小数点塞进字符串中, 将字符串分成四部分。
//    public List<String> restoreIpAddresses(String s) {
//        int length = length;
//        if(length < 4 || length > 12) return new LinkedList<>();
//        List<String> result = new LinkedList<>();
//        for(int i = 0; i < length - 3; i++){//i从0开始, 则每次将小数点放在第i个字符的后面
//            if((i+1) - 0 > 1 && s.charAt(0)=='0') continue;
//            for(int j = i + 1; j < length - 2; j++){
//                if((j+1) - (i+1) > 1 && s.charAt(i+1)=='0') continue;
//                for (int k = j + 1; k < length - 1; k++){
//                    if((k+1) - (j+1) > 1 && s.charAt(j+1)=='0') continue;
//                    if(length - (k+1) > 1 && s.charAt(k+1)=='0') continue;
//                    try{
//                        int address1 = Integer.parseInt(s.substring(0, i+1));
//                        int address2 = Integer.parseInt(s.substring(i+1, j+1));
//                        int address3 = Integer.parseInt(s.substring(j+1, k+1));
//                        int address4 = Integer.parseInt(s.substring(k+1, length));
//                        if(address1 < 256 && address2 < 256 && address3 < 256 && address4 < 256){
//                            result.add(address1 + "." + address2 + "." + address3 + "." + address4);
//                        }
//                    }catch (Exception e){
//                        return new LinkedList<>();
//                    }
//                }
//            }
//        }
//        return result;
//    }
//}

    //    class Solution {//解法二: 塞点法。改进版
//        public List<String> restoreIpAddresses(String s) {
//            int length = length;
//            if(length < 4 || length > 12) return new ArrayList<>();
//            List<String> result = new ArrayList<>();
//            for(int i = 1; i < length - 2; i++){//i从1开始, 则每次将小数点放在第i个字符的前面
//                if(i - 0 > 1 && s.charAt(0)=='0') continue;
//                for(int j = i + 1; j < length - 1; j++){
//                    if(j - i > 1 && s.charAt(i)=='0') continue;
//                    for (int k = j + 1; k < length; k++){
//                        if(k - j > 1 && s.charAt(j)=='0') continue;
//                        if(length - k > 1 && s.charAt(k)=='0') continue;
//                        try{
//                            int address1 = Integer.parseInt(s.substring(0, i));
//                            int address2 = Integer.parseInt(s.substring(i, j));
//                            int address3 = Integer.parseInt(s.substring(j, k));
//                            int address4 = Integer.parseInt(s.substring(k, length));
//                            if(address1 < 256 && address2 < 256 && address3 < 256 && address4 < 256){
//                                result.add(address1 + "." + address2 + "." + address3 + "." + address4);
//                            }
//                        }catch (Exception e){
//                            return new ArrayList<>();
//                        }
//                    }
//                }
//            }
//            return result;
//        }
//    }
//class Solution {//解法三: 塞点法。改进剪枝条件。
//    public List<String> restoreIpAddresses(String s) {
//        int length = length;
//        if(length < 4 || length > 12) return new ArrayList<>();
//        List<String> result = new LinkedList<>();
//        for(int i = 1; i < length - 2; i++){//i从1开始, 则每次将小数点放在第i个字符的前面
//            if(i - 0 > 3 || i - 0 > 1 && s.charAt(0)=='0') break;
//            for(int j = i + 1; j < length - 1; j++){
//                if(j - i > 3 || j - i > 1 && s.charAt(i)=='0') break;
//                for (int k = j + 1; k < length; k++){
//                    if(k-j > 3 || k - j > 1 && s.charAt(j)=='0') break;
//                    if(length - k > 3 || length - k > 1 && s.charAt(k)=='0') continue;
//                    try{
//                        int address1 = Integer.parseInt(s.substring(0, i));
//                        int address2 = Integer.parseInt(s.substring(i, j));
//                        int address3 = Integer.parseInt(s.substring(j, k));
//                        int address4 = Integer.parseInt(s.substring(k, length));
//                        if(address1 < 256 && address2 < 256 && address3 < 256 && address4 < 256){
//                            result.add(address1 + "." + address2 + "." + address3 + "." + address4);
//                        }
//                    }catch (Exception e){
//                        return new LinkedList<>();
//                    }
//                }
//            }
//        }
//        return result;
//    }
//}
//class Solution {//解法四。回溯算法(来自官方),以及我自己加的一句length<4或>12直接return的判断。
//    static final int SEG_COUNT = 4;
//    List<String> ans = new ArrayList<String>();
//    int[] segments = new int[SEG_COUNT];
//
//    public List<String> restoreIpAddresses(String s) {
//        if(length < 4 || length > 12) return new ArrayList<>(0);
//        dfs(s, 0, 0);
//        return ans;
//    }
//
//    public void dfs(String s, int segId, int segStart) {
//        // 如果找到了 4 段 IP 地址并且遍历完了字符串，那么就是一种答案
//        if (segId == SEG_COUNT) {
//            if (segStart == length) {
//                StringBuffer ipAddr = new StringBuffer();
//                for (int i = 0; i < SEG_COUNT - 1; ++i) {
//                    ipAddr.append(segments[i]);
//                    ipAddr.append('.');
//                }
//                ipAddr.append(segments[SEG_COUNT - 1]);
//                ans.add(ipAddr.toString());
//            }
//            return; //如果segStart != length,说明s最后还有剩余字符,直接return
//        }
//
//        // 如果还没有找到 4 段 IP 地址就已经遍历完了字符串，那么提前回溯
//        if (segStart == length) {
//            return;
//        }
//
//        // 由于不能有前导零，如果当前数字为 0，那么这一段 IP 地址只能为 0
//        if (s.charAt(segStart) == '0') {
//            segments[segId] = 0;
//            dfs(s, segId + 1, segStart + 1);
//        }
//
//        // 一般情况，枚举每一种可能性并递归
//        int addr = 0;
//        for (int segEnd = segStart; segEnd < length; ++segEnd) {
//            addr = addr * 10 + (s.charAt(segEnd) - '0');//用这种方式累积ip长度, 效率高于直接字符串截取很多
//            if (addr > 0 && addr <= 0xFF) {
//                segments[segId] = addr;
//                dfs(s, segId + 1, segEnd + 1);
//            } else {
//                break;
//            }
//        }
//    }
//}
    class Solution {//解法五。回溯算法(根据官方解法自写)。
        String s;
        int length;
        int[] ipSegments = new int[4];
        List<String> result = new ArrayList<>();

        public List<String> restoreIpAddresses(String s) {
            this.s = s;
            this.length = s.length();
            if(length < 4 || length > 12) return result;

            dfs(0,0);
            return result;
        }
        /**
         * @param segId segId合法的值为0,1,2,3,表示IP的四个IP段中的某个
         * @param segStartIndex 该IP段取的s串中的开始的索引
         */
        public void dfs(int segId, int segStartIndex){
            if(segId == 4){
                if(segStartIndex == length){//满足if条件则添加结果
                    StringBuilder ip = new StringBuilder();
                    for(int i = 0; i < 3; i++){
                        ip.append(ipSegments[i]);
                        ip.append('.');
                    }
                    ip.append(ipSegments[3]);
                    result.add(ip.toString());
                }
                return; //如果segStartIndex != length,说明s最后还有剩余字符,也是要直接return的
            }

            if(segStartIndex == length) return;

            if(s.charAt(segStartIndex) == '0') {
                ipSegments[segId] = 0;
                dfs(segId + 1, segStartIndex + 1);
                return;//这个return加上比较利于理解, 不加也可以, 因为0在后面的for循环if条件进不去。
            }

            int segValue = 0;
            for(int segEnd = segStartIndex; segEnd < length; segEnd++){
                segValue = (s.charAt(segEnd) - '0') + segValue * 10;
                if(0 < segValue && segValue <= 255) {
                    ipSegments[segId] = segValue;
                    dfs(segId + 1,segEnd + 1);
                }else break;  //不在这个范围内直接break 结束循环
            }
        }
    }

//leetcode submit region end(Prohibit modification and deletion)

}