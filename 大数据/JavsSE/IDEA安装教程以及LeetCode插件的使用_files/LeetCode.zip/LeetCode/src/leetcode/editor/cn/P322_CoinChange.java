package leetcode.editor.cn;
//给你一个整数数组 coins ，表示不同面额的硬币；以及一个整数 amount ，表示总金额。 
//
// 计算并返回可以凑成总金额所需的 最少的硬币个数 。如果没有任何一种硬币组合能组成总金额，返回 -1 。 
//
// 你可以认为每种硬币的数量是无限的。 
//
// 
//
// 示例 1： 
//
// 
//输入：coins = [1, 2, 5], amount = 11
//输出：3 
//解释：11 = 5 + 5 + 1 
//
// 示例 2： 
//
// 
//输入：coins = [2], amount = 3
//输出：-1 
//
// 示例 3： 
//
// 
//输入：coins = [1], amount = 0
//输出：0
// 
//
// 示例 4： 
//
// 
//输入：coins = [1], amount = 1
//输出：1
// 
//
// 示例 5： 
//
// 
//输入：coins = [1], amount = 2
//输出：2
// 
//
// 
//
// 提示： 
//
// 
// 1 <= coins.length <= 12 
// 1 <= coins[i] <= 231 - 1 
// 0 <= amount <= 104 
// 
// Related Topics 广度优先搜索 数组 动态规划 
// 👍 1471 👎 0


import java.util.Arrays;

//java:零钱兑换
public class P322_CoinChange{
    public static void main(String[] args) {
        Solution solution = new P322_CoinChange().new Solution();
        //测试代码:
        
    }    
//leetcode submit region begin(Prohibit modification and deletion)
class Solution {
    int result = Integer.MAX_VALUE;
    public int coinChange(int[] coins, int amount) {
        Arrays.sort(coins);
        dfs(coins,amount,0,0,coins.length-1);
        return result == Integer.MAX_VALUE ? -1 : result;
    }
    private void dfs(int[] coins, int amount, int countCoins, int sumAmount, int index){
        if(sumAmount == amount){
            result = Math.min(result, countCoins);
            return;
        }
        if(sumAmount > amount || countCoins > result){
            return;
        }
        for(int i = amount/coins[index]; i >= 0; i--){
            dfs(coins, amount, countCoins + 1, sumAmount + i * coins[index],index - 1);
        }
    }
}
//leetcode submit region end(Prohibit modification and deletion)

}