package leetcode.editor.cn;
//0,1,···,n-1这n个数字排成一个圆圈，从数字0开始，每次从这个圆圈里删除第m个数字（删除后从下一个数字开始计数）。求出这个圆圈里剩下的最后一个数字。
// 
//
// 例如，0、1、2、3、4这5个数字组成一个圆圈，从数字0开始每次删除第3个数字，则删除的前4个数字依次是2、0、4、1，因此最后剩下的数字是3。 
//
// 
//
// 示例 1： 
//
// 
//输入: n = 5, m = 3
//输出: 3
// 
//
// 示例 2： 
//
// 
//输入: n = 10, m = 17
//输出: 2
// 
//
// 
//
// 限制： 
//
// 
// 1 <= n <= 10^5 
// 1 <= m <= 10^6 
// 
// Related Topics 递归 数学 
// 👍 412 👎 0


import java.util.ArrayList;

//java:圆圈中最后剩下的数字
public class P剑指_offer_62_YuanQuanZhongZuiHouShengXiaDeShuZiLcof{
    public static void main(String[] args) {
        Solution solution = new P剑指_offer_62_YuanQuanZhongZuiHouShengXiaDeShuZiLcof().new Solution();
        //测试代码:
        
    }    
//leetcode submit region begin(Prohibit modification and deletion)
//class Solution {//解法一。暴力解法（执行超时）。 新建一个链表。依次删除元素。时间复杂度O(mn)，空间复杂度O(n)
//    public int lastRemaining(int n, int m) {
//        if(n == 1 || m == 1) return n-1; //这步需要判断。
//
//        Link head = new Link(0);
//        Link link = head;
//        for(int i = 1; i < n; i++){ //新建一个长度为n的链表
//            link.next = new Link(i);
//            link = link.next;
//        }
//        link.next = head;
//
//        link = head;  //将link重置为head，开始删除元素。
//        while(link.next != link){
//            for(int step = 1; step < m - 1; step++){ //注意这里循环的次数为m-2次，也就是每次走m-2步
//                link = link.next;
//            }
//            link.next = link.next.next;
//            link = link.next;
//        }
//        return link.element;
//    }
//}
//    class Link{ //添加一个链表类作为链表数据结构
//        int element;
//        Link next;
//        Link(int element){
//            this.element = element;
//        }
//    }
class Solution {//解法二。来自大神。暴力解法要用ArrayList存储才不会超时，
    public int lastRemaining(int n, int m) {
        ArrayList<Integer> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(i);
        }
        int idx = 0;
        while (n > 1) {
            idx = (idx + m - 1) % n;  //既然是数组，不是链表了，那就可以直接用递推式随机访问元素了。
            list.remove(idx);
            n--; //注意n要随着元素的删除递减
        }
        return list.get(0);
    }
}

//class Solution {//解法二。递归求解。来自官方解法（但解题思路写的没有k神好）。时间复杂度O(n)，空间复杂度O(n)
//    public int lastRemaining(int n, int m) {
//        if (n == 1) {
//            return 0;
//        }
//        int x = lastRemaining(n - 1, m);
//        return (m + x) % n;
//    }
//}

//class Solution {//解法三。来自k神。动态规划。时间复杂度O(n)，空间复杂度O(1)
//    public int lastRemaining(int n, int m) {
//        int x = 0;
//        for(int i = 2; i <= n; i++){
//            x = (m + x) % i;
//        }
//        return x;
//    }
//}

//leetcode submit region end(Prohibit modification and deletion)

}